<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 2.0
        </div>
        <strong>Copyright &copy; 2024 <a href="http://app.grabupdates.com/">FSM 2.0</a>.</strong> All rights reserved.
      </footer>